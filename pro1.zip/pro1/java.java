import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyFirstApp {
    public static void main(String[] args) {
        // Δημιουργία του παραθύρου
        JFrame frame = new JFrame("My First App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Δημιουργία panel και στοιχείων GUI
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Hello, World!");
        JButton button = new JButton("Click Me!");

        // Προσθήκη action listener στο κουμπί
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                label.setText("Button clicked!");
            }
        });

        // Προσθήκη των στοιχείων στο panel και του panel στο frame
        panel.add(label);
        panel.add(button);
        frame.add(panel);

        // Εμφάνιση του παραθύρου
        frame.setVisible(true);
    }
}
