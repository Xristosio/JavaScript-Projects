console.log("Hello World!")
console.log("Javascript Test")