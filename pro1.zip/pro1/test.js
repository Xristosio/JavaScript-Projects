function geekFunc() {
    let a = 10;
    try {
        console.log("Value of variable a is : " + a);
        throw new Error('Yeah... Sorry');

    }
    catch (e) {
        console.log("Error: " + e.description);
    }
}
geekFunc();
